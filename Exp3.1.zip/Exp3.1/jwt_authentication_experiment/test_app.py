"""Basic automated tests for the JWT authentication experiment."""
import unittest
import app as auth_app


class JWTAuthTests(unittest.TestCase):
    def setUp(self):
        auth_app.app.config["TESTING"] = True
        self.client = auth_app.app.test_client()
        auth_app.users_by_email.clear()
        auth_app.next_user_id = 1

    def register(self):
        return self.client.post("/api/register", json={
            "username": "Student", "email": "student@example.com",
            "password": "ExamplePass123!"
        })

    def login(self):
        return self.client.post("/api/login", json={
            "email": "student@example.com", "password": "ExamplePass123!"
        })

    def test_health(self):
        self.assertEqual(self.client.get("/api/health").status_code, 200)

    def test_register_and_reject_duplicate(self):
        self.assertEqual(self.register().status_code, 201)
        self.assertEqual(self.register().status_code, 409)

    def test_reject_short_password(self):
        response = self.client.post("/api/register", json={
            "username": "Student", "email": "student@example.com", "password": "short"
        })
        self.assertEqual(response.status_code, 400)

    def test_login_and_protected_route(self):
        self.assertEqual(self.register().status_code, 201)
        response = self.login()
        self.assertEqual(response.status_code, 200)
        token = response.get_json()["access_token"]
        profile = self.client.get("/api/me", headers={
            "Authorization": f"Bearer {token}"
        })
        self.assertEqual(profile.status_code, 200)
        self.assertEqual(profile.get_json()["user"]["email"], "student@example.com")

    def test_protected_route_without_token(self):
        self.assertEqual(self.client.get("/api/me").status_code, 401)

    def test_invalid_password(self):
        self.register()
        response = self.client.post("/api/login", json={
            "email": "student@example.com", "password": "wrong-password"
        })
        self.assertEqual(response.status_code, 401)


if __name__ == "__main__":
    unittest.main()
