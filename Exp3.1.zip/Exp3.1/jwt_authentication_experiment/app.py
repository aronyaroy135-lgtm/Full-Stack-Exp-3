"""Educational JWT authentication API. Do not use the development server in production."""
import os
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from flask import Flask, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)

# For local learning only, a fallback is provided. Set JWT_SECRET in real deployments.
JWT_SECRET = os.environ.get("JWT_SECRET", "development-only-change-this-secret")
JWT_ALGORITHM = "HS256"
try:
    JWT_EXPIRES_MINUTES = max(1, int(os.environ.get("JWT_EXPIRES_MINUTES", "30")))
except ValueError:
    JWT_EXPIRES_MINUTES = 30

# In-memory store for this experiment; accounts disappear when the server restarts.
users_by_email = {}
next_user_id = 1


def create_access_token(user):
    now = datetime.now(timezone.utc)
    claims = {
        "sub": str(user["id"]),
        "email": user["email"],
        "iat": now,
        "exp": now + timedelta(minutes=JWT_EXPIRES_MINUTES),
    }
    return jwt.encode(claims, JWT_SECRET, algorithm=JWT_ALGORITHM)


def require_auth(handler):
    @wraps(handler)
    def wrapped(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        scheme, _, token = header.partition(" ")
        if scheme.lower() != "bearer" or not token.strip():
            return jsonify(error="Missing Bearer token"), 401
        try:
            claims = jwt.decode(
                token.strip(),
                JWT_SECRET,
                algorithms=[JWT_ALGORITHM],
                options={"require": ["sub", "iat", "exp"]},
            )
        except jwt.ExpiredSignatureError:
            return jsonify(error="Token has expired; please log in again"), 401
        except jwt.InvalidTokenError:
            return jsonify(error="Invalid token"), 401

        user = next((u for u in users_by_email.values()
                     if str(u["id"]) == claims.get("sub")), None)
        if user is None:
            return jsonify(error="User no longer exists"), 401
        return handler(user, *args, **kwargs)
    return wrapped


@app.get("/api/health")
def health():
    return jsonify(status="ok", service="JWT Authentication Experiment")


@app.post("/api/register")
def register():
    global next_user_id
    data = request.get_json(silent=True) or {}
    username = data.get("username", "")
    email = data.get("email", "")
    password = data.get("password", "")

    if not all(isinstance(v, str) for v in (username, email, password)):
        return jsonify(error="username, email, and password must be strings"), 400
    username, email = username.strip(), email.strip().lower()
    if not username or not email or not password:
        return jsonify(error="username, email, and password are required"), 400
    if len(password) < 8:
        return jsonify(error="Password must be at least 8 characters"), 400
    if "@" not in email or "." not in email.rsplit("@", 1)[-1]:
        return jsonify(error="Enter a valid email address"), 400
    if email in users_by_email:
        return jsonify(error="An account with this email already exists"), 409

    user = {
        "id": next_user_id,
        "username": username,
        "email": email,
        "password_hash": generate_password_hash(password),
    }
    next_user_id += 1
    users_by_email[email] = user
    return jsonify(message="Registration successful", user={
        "id": user["id"], "username": user["username"], "email": user["email"]
    }), 201


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "")
    password = data.get("password", "")
    if not isinstance(email, str) or not isinstance(password, str):
        return jsonify(error="email and password must be strings"), 400
    user = users_by_email.get(email.strip().lower())
    if user is None or not check_password_hash(user["password_hash"], password):
        return jsonify(error="Invalid email or password"), 401

    return jsonify(
        message="Login successful",
        access_token=create_access_token(user),
        token_type="Bearer",
        expires_in=JWT_EXPIRES_MINUTES * 60,
        user={"id": user["id"], "username": user["username"], "email": user["email"]},
    ), 200


@app.get("/api/me")
@require_auth
def me(user):
    return jsonify(user={
        "id": user["id"], "username": user["username"], "email": user["email"]
    })


if __name__ == "__main__":
    # Debug is disabled to avoid exposing the interactive debugger.
    app.run(host="127.0.0.1", port=5000, debug=False)
