"""Educational Flask application demonstrating JWT authentication and RBAC."""
import os
from datetime import datetime, timedelta, timezone
from functools import wraps

import jwt
from flask import Flask, jsonify, request
from werkzeug.security import check_password_hash, generate_password_hash

app = Flask(__name__)
JWT_SECRET = os.environ.get("JWT_SECRET", "development-only-change-this-secret")
JWT_ALGORITHM = "HS256"
try:
    JWT_EXPIRES_MINUTES = max(1, int(os.environ.get("JWT_EXPIRES_MINUTES", "30")))
except ValueError:
    JWT_EXPIRES_MINUTES = 30

# Role-to-permission mapping. Keep authorization policy in one place.
ROLE_PERMISSIONS = {
    "user": {"profile:read", "dashboard:read"},
    "admin": {"profile:read", "dashboard:read", "report:read", "users:read"},
}

# In-memory demonstration database. Data is reset when the app restarts.
users_by_email = {}
next_user_id = 1


def add_demo_user(username, email, password, role):
    """Create a demo user once, storing only a password hash."""
    global next_user_id
    users_by_email[email] = {
        "id": next_user_id,
        "username": username,
        "email": email,
        "password_hash": generate_password_hash(password),
        "role": role,
    }
    next_user_id += 1


def seed_demo_users():
    if not users_by_email:
        add_demo_user("Standard User", "user@example.com", "UserPass123!", "user")
        add_demo_user("Administrator", "admin@example.com", "AdminPass123!", "admin")


def public_user(user):
    return {
        "id": user["id"],
        "username": user["username"],
        "email": user["email"],
        "role": user["role"],
    }


def create_access_token(user):
    now = datetime.now(timezone.utc)
    claims = {
        "sub": str(user["id"]),
        "iat": now,
        "exp": now + timedelta(minutes=JWT_EXPIRES_MINUTES),
    }
    return jwt.encode(claims, JWT_SECRET, algorithm=JWT_ALGORITHM)


def require_auth(handler):
    """Validate JWT and pass the current user record to the route."""
    @wraps(handler)
    def wrapped(*args, **kwargs):
        header = request.headers.get("Authorization", "")
        scheme, _, token = header.partition(" ")
        if scheme.lower() != "bearer" or not token.strip():
            return jsonify(error="Missing Bearer token"), 401
        try:
            claims = jwt.decode(
                token.strip(),
                JWT_SECRET,
                algorithms=[JWT_ALGORITHM],
                options={"require": ["sub", "iat", "exp"]},
            )
        except jwt.ExpiredSignatureError:
            return jsonify(error="Token expired; please log in again"), 401
        except jwt.InvalidTokenError:
            return jsonify(error="Invalid token"), 401

        user = next((item for item in users_by_email.values()
                     if str(item["id"]) == claims.get("sub")), None)
        if user is None:
            return jsonify(error="User not found"), 401
        return handler(user, *args, **kwargs)
    return wrapped


def require_permission(permission):
    """Decorator: require authentication plus a specific permission."""
    def decorator(handler):
        @wraps(handler)
        @require_auth
        def wrapped(user, *args, **kwargs):
            permissions = ROLE_PERMISSIONS.get(user["role"], set())
            if permission not in permissions:
                return jsonify(error="Forbidden: insufficient permissions",
                               required_permission=permission), 403
            return handler(user, *args, **kwargs)
        return wrapped
    return decorator


@app.get("/api/health")
def health():
    return jsonify(status="ok", service="RBAC Access Control Experiment")


@app.post("/api/login")
def login():
    data = request.get_json(silent=True) or {}
    email = data.get("email", "")
    password = data.get("password", "")
    if not isinstance(email, str) or not isinstance(password, str):
        return jsonify(error="email and password must be strings"), 400

    seed_demo_users()
    user = users_by_email.get(email.strip().lower())
    if user is None or not check_password_hash(user["password_hash"], password):
        return jsonify(error="Invalid email or password"), 401

    return jsonify(
        message="Login successful",
        access_token=create_access_token(user),
        token_type="Bearer",
        expires_in=JWT_EXPIRES_MINUTES * 60,
        user=public_user(user),
    ), 200


@app.get("/api/me")
@require_permission("profile:read")
def me(user):
    return jsonify(user=public_user(user))


@app.get("/api/dashboard")
@require_permission("dashboard:read")
def dashboard(user):
    return jsonify(message="Welcome to the dashboard", role=user["role"])


@app.get("/api/admin/report")
@require_permission("report:read")
def admin_report(user):
    return jsonify(
        report="Confidential administration report",
        generated_for=user["username"],
        message="Access granted: administrator permission verified",
    )


@app.get("/api/admin/users")
@require_permission("users:read")
def admin_users(user):
    return jsonify(users=[public_user(item) for item in users_by_email.values()])


seed_demo_users()

if __name__ == "__main__":
    # Debug is disabled to avoid exposing the interactive debugger.
    app.run(host="127.0.0.1", port=5000, debug=False)
