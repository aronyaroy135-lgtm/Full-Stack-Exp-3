"""Automated tests for JWT authentication and role-based authorization."""
import unittest
import app as rbac_app


class RBACTests(unittest.TestCase):
    def setUp(self):
        rbac_app.app.config["TESTING"] = True
        self.client = rbac_app.app.test_client()
        rbac_app.users_by_email.clear()
        rbac_app.next_user_id = 1
        rbac_app.seed_demo_users()

    def token_for(self, email, password):
        response = self.client.post("/api/login", json={
            "email": email, "password": password
        })
        self.assertEqual(response.status_code, 200)
        return response.get_json()["access_token"]

    def headers(self, token):
        return {"Authorization": f"Bearer {token}"}

    def test_public_health(self):
        self.assertEqual(self.client.get("/api/health").status_code, 200)

    def test_user_can_access_dashboard(self):
        token = self.token_for("user@example.com", "UserPass123!")
        response = self.client.get("/api/dashboard", headers=self.headers(token))
        self.assertEqual(response.status_code, 200)

    def test_user_is_forbidden_from_admin_report(self):
        token = self.token_for("user@example.com", "UserPass123!")
        response = self.client.get("/api/admin/report", headers=self.headers(token))
        self.assertEqual(response.status_code, 403)

    def test_admin_can_access_admin_report(self):
        token = self.token_for("admin@example.com", "AdminPass123!")
        response = self.client.get("/api/admin/report", headers=self.headers(token))
        self.assertEqual(response.status_code, 200)

    def test_missing_token_is_unauthorized(self):
        response = self.client.get("/api/me")
        self.assertEqual(response.status_code, 401)

    def test_invalid_password_is_rejected(self):
        response = self.client.post("/api/login", json={
            "email": "user@example.com", "password": "wrong-password"
        })
        self.assertEqual(response.status_code, 401)

    def test_admin_can_list_users(self):
        token = self.token_for("admin@example.com", "AdminPass123!")
        response = self.client.get("/api/admin/users", headers=self.headers(token))
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(len(response.get_json()["users"]), 2)


if __name__ == "__main__":
    unittest.main()
