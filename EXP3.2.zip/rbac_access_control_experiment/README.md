# Experiment: Role-Based Access Control (RBAC) for Secure Application Routes

## Aim
To implement role-based access control and secure application routes based on user permissions.

## Objectives
1. Define roles and map them to permissions.
2. Authenticate users with email and password.
3. Issue signed JWT access tokens containing the user's role.
4. Protect application routes using authentication and permission checks.
5. Verify that users can access only routes allowed by their roles.

## Software requirements
- Python 3.10+
- Flask
- PyJWT
- Werkzeug

## Theory
Role-Based Access Control (RBAC) assigns permissions to roles rather than granting every permission individually to each user. A user receives a role, and that role determines which protected actions the user may perform.

This experiment defines two roles:
- `user`: can view their own profile and access the basic dashboard.
- `admin`: can access the basic dashboard, view the admin report, and list registered users.

A JWT is issued after login. The server validates its signature and expiry before allowing access to protected routes. The server then checks the user's current role against the permission required by the route. Passwords are stored as password hashes, not plain text.

**Security note:** JWT payloads are signed, not encrypted. Do not store secrets in them. This is an educational example with in-memory storage and a development secret fallback. For production, use a persistent database, a strong secret from an environment variable/secret manager, HTTPS, rate limiting, audit logging, and a considered token revocation strategy. The server checks the current role from its user store instead of trusting only the role claim in the token.

## Project structure
```text
rbac_access_control_experiment/
├── app.py
├── requirements.txt
├── .env.example
├── .gitignore
├── test_app.py
└── README.md
```

## Installation and execution
1. Install Python 3.10 or later.
2. Open a terminal in this folder.
3. Create and activate a virtual environment:
   - Windows: `py -m venv .venv` then `.venv\\Scripts\\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install dependencies: `pip install -r requirements.txt`
5. Set a secret key (recommended):
   - Windows PowerShell: `$env:JWT_SECRET="replace-with-a-long-random-secret"`
   - macOS/Linux: `export JWT_SECRET="replace-with-a-long-random-secret"`
6. Run the server: `python app.py`
7. Base URL: `http://127.0.0.1:5000`

## Demo accounts
For easy classroom testing, the app creates these demo accounts at startup:
- User: `user@example.com` / `UserPass123!`
- Admin: `admin@example.com` / `AdminPass123!`

These are demonstration credentials only. Do not use them in a deployed system.

## API endpoints
| Method | Endpoint | Access |
|---|---|---|
| GET | `/api/health` | Public |
| POST | `/api/login` | Public |
| GET | `/api/me` | Any authenticated user |
| GET | `/api/dashboard` | `user` or `admin` |
| GET | `/api/admin/report` | `admin` only |
| GET | `/api/admin/users` | `admin` only |

### Login example
Send JSON to `POST /api/login`:
```json
{"email":"user@example.com","password":"UserPass123!"}
```
The response includes an `access_token`. Send it in the request header:
```text
Authorization: Bearer <access_token>
```

### Example using curl
```bash
curl -X POST http://127.0.0.1:5000/api/login -H "Content-Type: application/json" -d "{\"email\":\"admin@example.com\",\"password\":\"AdminPass123!\"}"
```
Use the token from the response:
```bash
curl http://127.0.0.1:5000/api/admin/report -H "Authorization: Bearer YOUR_TOKEN_HERE"
```
Try the admin route with the user account token; it should return HTTP `403 Forbidden`.

## Algorithm
1. Start the Flask application and load the JWT signing secret.
2. Define roles and their permissions.
3. Authenticate a user by verifying their password hash.
4. Generate a signed JWT with the user's ID, issue time, and expiry.
5. For a protected request, extract the Bearer token.
6. Verify the token signature and expiry.
7. Look up the user and obtain their current role from the user store.
8. Check whether the role includes the permission required by the route.
9. Return the requested data if authorized; otherwise return `401 Unauthorized` or `403 Forbidden`.

## Expected output
- A valid login returns a JWT.
- An authenticated user can access `/api/me` and `/api/dashboard`.
- A standard user attempting an admin-only route receives `403 Forbidden`.
- An administrator can access admin-only routes.
- Requests with missing, invalid, or expired tokens are rejected.

## Result
The experiment implements RBAC by associating permissions with roles and enforcing those permissions on protected routes after JWT authentication.
